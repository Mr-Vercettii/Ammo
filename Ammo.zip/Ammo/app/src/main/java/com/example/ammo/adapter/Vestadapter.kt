package com.example.ammo.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.ammo.Classammo
import com.example.ammo.Classvest
import com.example.ammo.R

class Vestadapter(private val vestList: List<Classvest>, private val onClickListener: (Classvest) -> Unit) : RecyclerView.Adapter<Vestviewholder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Vestviewholder {
        val layoutInflater = LayoutInflater.from(parent.context)
        return Vestviewholder(layoutInflater.inflate(R.layout.item_chaleco,parent,false))
    }

    override fun getItemCount(): Int = vestList.size



    override fun onBindViewHolder(holder: Vestviewholder, position: Int) {
        val item = vestList[position]
        holder.render(item,onClickListener)
    }
}