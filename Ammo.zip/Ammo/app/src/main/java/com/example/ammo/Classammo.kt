package com.example.ammo

data class Classammo (
    val nombre: String,
    val imagen: String,
    val energia: String,
    val velocidad: String,
    val tipo: String,
    val precio: String,
)
