package com.example.ammo.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.ammo.Classaccesorios
import com.example.ammo.Classammo
import com.example.ammo.R

class Accesoryadapter(private val accesoryList: List<Classaccesorios>, private val onClickListener: (Classaccesorios) -> Unit) : RecyclerView.Adapter<Accesoryviewholder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Accesoryviewholder {
        val layoutInflater = LayoutInflater.from(parent.context)
        return Accesoryviewholder(layoutInflater.inflate(R.layout.item_accesorio,parent,false))
    }

    override fun getItemCount(): Int = accesoryList.size



    override fun onBindViewHolder(holder: Accesoryviewholder, position: Int) {
        val item = accesoryList[position]
        holder.render(item,onClickListener)
    }
}