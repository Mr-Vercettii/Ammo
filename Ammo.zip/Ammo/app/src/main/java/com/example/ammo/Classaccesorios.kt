package com.example.ammo

data class Classaccesorios (
    val nombre: String,
    val imagen: String,
    val colour: String,
)