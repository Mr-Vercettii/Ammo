package com.example.ammo

import android.os.Bundle
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.ammo.adapter.Accesoryadapter
import com.example.ammo.adapter.Ammoadapter
import com.example.ammo.databinding.ActivityAccesoriosBinding
import com.example.ammo.databinding.ActivityCalibresBinding

class Accesorios : AppCompatActivity() {
    private lateinit var binding: ActivityAccesoriosBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding= ActivityAccesoriosBinding.inflate(layoutInflater)
        setContentView(binding.root)
        initRecyclerView()

    }
    private fun initRecyclerView() {
        val recyclerView = findViewById<RecyclerView>(R.id.recycleracc)
        val manager = LinearLayoutManager(this)
        recyclerView.layoutManager = manager

        recyclerView.adapter = Accesoryadapter(Accesoryprovder.accesorylist) {
            onItemSelected(it)
        }
    }

    private fun onItemSelected(accesory:Classaccesorios) {
        Toast.makeText(this, accesory.nombre, Toast.LENGTH_SHORT).show()
    }
}