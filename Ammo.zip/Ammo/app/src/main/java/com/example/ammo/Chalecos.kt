package com.example.ammo

import android.os.Bundle
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.ammo.adapter.Ammoadapter
import com.example.ammo.adapter.Vestadapter
import com.example.ammo.databinding.ActivityCalibresBinding
import com.example.ammo.databinding.ActivityChalecosBinding
import com.example.vest.Vestprovider

class Chalecos : AppCompatActivity() {
    private lateinit var binding: ActivityChalecosBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding= ActivityChalecosBinding.inflate(layoutInflater)
        setContentView(binding.root)
        initRecyclerView()

    }
    private fun initRecyclerView() {
        val recyclerView = findViewById<RecyclerView>(R.id.recyclervest)
        val manager = LinearLayoutManager(this)
        recyclerView.layoutManager = manager

        recyclerView.adapter = Vestadapter(Vestprovider.vestlist) {
            onItemSelected(it)
        }
    }

    private fun onItemSelected(vest:Classvest) {
        Toast.makeText(this, vest.nombre, Toast.LENGTH_SHORT).show()
    }
}