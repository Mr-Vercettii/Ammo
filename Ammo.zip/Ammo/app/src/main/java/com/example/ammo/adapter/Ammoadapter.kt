package com.example.ammo.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.ammo.Classammo
import com.example.ammo.R

class Ammoadapter(private val ammoList: List<Classammo>, private val onClickListener: (Classammo) -> Unit) : RecyclerView.Adapter<Ammoviewholder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Ammoviewholder {
        val layoutInflater = LayoutInflater.from(parent.context)
        return Ammoviewholder(layoutInflater.inflate(R.layout.item_calibre,parent,false))
    }

    override fun getItemCount(): Int = ammoList.size



    override fun onBindViewHolder(holder: Ammoviewholder, position: Int) {
        val item = ammoList[position]
        holder.render(item,onClickListener)
    }
}