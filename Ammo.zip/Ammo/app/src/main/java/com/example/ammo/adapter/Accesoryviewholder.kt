package com.example.ammo.adapter

import android.view.View
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.ammo.Classaccesorios
import com.example.ammo.Classammo
import com.example.ammo.databinding.ItemAccesorioBinding
import com.example.ammo.databinding.ItemCalibreBinding

class Accesoryviewholder(view:View):RecyclerView.ViewHolder(view) {
    val binding = ItemAccesorioBinding.bind(view)
    fun render(accesorymodel:Classaccesorios, OnClickListener: (Classaccesorios) -> Unit){
        binding.nombreacc.text=accesorymodel.nombre
        binding.color.text=accesorymodel.colour
        Glide.with(binding.imagenacc.context).load(accesorymodel.imagen).into(binding.imagenacc)

        itemView.setOnClickListener { OnClickListener(accesorymodel) }
    }
}