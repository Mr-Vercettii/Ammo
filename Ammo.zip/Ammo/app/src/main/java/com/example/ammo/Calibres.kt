package com.example.ammo

import android.os.Bundle
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.ammo.adapter.Ammoadapter
import com.example.ammo.databinding.ActivityCalibresBinding

class Calibres : AppCompatActivity() {
    private lateinit var binding:ActivityCalibresBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding=ActivityCalibresBinding.inflate(layoutInflater)
        setContentView(binding.root)
        initRecyclerView()

    }
    private fun initRecyclerView() {
        val recyclerView = findViewById<RecyclerView>(R.id.recyclerammo)
        val manager = LinearLayoutManager(this)
        recyclerView.layoutManager = manager

        recyclerView.adapter = Ammoadapter(Ammoprovider.ammolist) {
            onItemSelected(it)
        }
    }

    private fun onItemSelected(ammo:Classammo) {
        Toast.makeText(this, ammo.nombre, Toast.LENGTH_SHORT).show()
        }
}