package com.example.ammo.adapter

import android.view.View
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.ammo.Classammo
import com.example.ammo.Classvest
import com.example.ammo.databinding.ItemCalibreBinding
import com.example.ammo.databinding.ItemChalecoBinding

class Vestviewholder(view:View):RecyclerView.ViewHolder(view) {
    val binding = ItemChalecoBinding.bind(view)
    fun render(vestModel:Classvest, OnClickListener: (Classvest) -> Unit){
        binding.vestnomb.text=vestModel.nombre
        binding.peso.text=vestModel.peso
        binding.nivel.text=vestModel.lvl
        Glide.with(binding.vestimg.context).load(vestModel.imagen).into(binding.vestimg)

        itemView.setOnClickListener { OnClickListener(vestModel) }
    }
}