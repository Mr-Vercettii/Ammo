package com.example.ammo

data class Classvest (
    val nombre: String,
    val imagen: String,
    val peso: String,
    val lvl: String,
)