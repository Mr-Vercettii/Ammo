package com.example.ammo

class Accesoryprovder {
    companion object{
        val accesorylist: List<Classaccesorios>
            get() = listOf<Classaccesorios>(
                Classaccesorios(
                    nombre = "Rail Master",
                    imagen = "https://galleryofguns.com/prod_images/CMR-207.jpg",
                    colour = "Rojo",
                ),
                Classaccesorios(
                    nombre = "Holosun",
                    imagen = "https://galleryofguns.com/prod_images/rmlt-gr.jpg",
                    colour = "Verde",
                ),
            )
    }
}