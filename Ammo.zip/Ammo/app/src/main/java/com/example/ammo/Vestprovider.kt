package com.example.vest

import com.example.ammo.Classvest

class Vestprovider {
    companion object{
        val vestlist: List<Classvest>
            get() = listOf<Classvest>(
                Classvest(
                    nombre = "Leonidas Legend Plate Carrier and Hercules Xtreme Level IV",
                    imagen = "https://cdn11.bigcommerce.com/s-4iwpyceis0/images/stencil/1280x1280/products/701/7009/Leonidas_Legend_Hercules_X_Pack_-_Black__51826.1695398521.jpg?c=2",
                    peso = "6.1 lbs Por Placa",
                    lvl = "4",
                ),
                Classvest(
                    nombre = "All American Bundle | AR550 Steel Medium ESAPI Body Armor with Leonidas Legend Plate Carrier",
                    imagen = "https://cdn11.bigcommerce.com/s-4iwpyceis0/images/stencil/1280x1280/products/823/7049/All_American_Bundle_-_9.5x12.5_Medium_ESAPI_AR550_Steel_-_Leo_Legend_-_Black__75653.1696268109.jpg?c=2",
                    peso = "8 lbs por placa",
                    lvl = "3+",
                ),
                Classvest(
                    nombre = "Spartan Armor Systems Tactical Level IIIA Certified Wraparound Bulletproof Vest",
                    imagen = "https://cdn11.bigcommerce.com/s-4iwpyceis0/images/stencil/1280x1280/products/610/3398/wraparound-body-armor-tactical-vest-IIIA-qtr__59098.1567096988.jpg?c=2",
                    peso = "Depende del tamaño",
                    lvl = "3A",
                ),
            )
    }
}