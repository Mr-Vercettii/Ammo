package com.example.ammo.adapter

import android.view.View
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.ammo.Classammo
import com.example.ammo.databinding.ItemCalibreBinding

class Ammoviewholder(view:View):RecyclerView.ViewHolder(view) {
    val binding = ItemCalibreBinding.bind(view)
    fun render(calibreModel:Classammo, OnClickListener: (Classammo) -> Unit){
        binding.tvN.text=calibreModel.nombre
        binding.tve.text=calibreModel.energia
        binding.tvp.text=calibreModel.precio
        binding.tvt.text=calibreModel.tipo
        binding.tvv.text=calibreModel.velocidad
        Glide.with(binding.ivF.context).load(calibreModel.imagen).into(binding.ivF)

        itemView.setOnClickListener { OnClickListener(calibreModel) }
    }
}