package com.example.ammo

class Ammoprovider {
    companion object{
        val ammolist: List<Classammo>
            get() = listOf<Classammo>(
                Classammo(
                    nombre = "Prvi Partizan Rangemaster 5.56x45 Ammo - 1000 Rounds of 55 Grain FMJBT",
                    imagen = "https://d1w4q6ldc8l0qo.cloudfront.net/media/catalog/product/cache/8/image/630x630/4ca400bbce702bae632024287a0688fb/5/e/5ed67ed4571f1a4dc5b32658a9e06eb5.jpg",
                    energia = "1282 ft lbs",
                    velocidad = "3240 FPS",
                    tipo = "Latón",
                    precio = "$499.99"
                ),
                Classammo(
                    nombre = "Igman 7.62x39 Ammo - 840 Rounds of 123 Grain FMJ",
                    imagen = "https://d1w4q6ldc8l0qo.cloudfront.net/media/catalog/product/cache/8/image/630x630/4ca400bbce702bae632024287a0688fb/4/f/4f81d7a8de9c9d42ddca84dcc1c4c167.jpg",
                    energia = "1776 ft lbs",
                    velocidad = "2550 FPS",
                    tipo = "Acero",
                    precio = "$474.99"
                ),
                Classammo(
                    nombre = "Armscor 357 Magnum Ammo - 50 Rounds of 158 Grain FMJ",
                    imagen = "https://d1w4q6ldc8l0qo.cloudfront.net/media/catalog/product/cache/8/image/630x630/4ca400bbce702bae632024287a0688fb/f/d/fdcb516ad531071cf1194d4c0ef37131.jpg",
                    energia = "823 ft lbs",
                    velocidad = "1545 FPS",
                    tipo = "Latón",
                    precio = "$33.99"
                ),
                Classammo(
                    nombre = "PMC Bronze 44 Magnum Ammo - 500 Rounds of 180 Grain JHP",
                    imagen = "https://d1w4q6ldc8l0qo.cloudfront.net/media/catalog/product/cache/8/image/630x630/4ca400bbce702bae632024287a0688fb/2/5/255d3f8b37d43db6932bb5379cc20a47_4.jpg",
                    energia = "1225 ft lbs",
                    velocidad = "1750 FPS",
                    tipo = "Latón",
                    precio = "$419.99"
                ),
                Classammo(
                    nombre = "Underwood 50 Action Express Ammo - 200 Rounds of 300 Grain FMJ Ammunition",
                    imagen = "https://d1w4q6ldc8l0qo.cloudfront.net/media/catalog/product/cache/8/image/630x630/4ca400bbce702bae632024287a0688fb/0/8/08e0478fb4d0ea13720204a18b5be1a8.jpg",
                    energia = "1663 ft lbs",
                    velocidad = "1580 FPS",
                    tipo = "Nickel-Latón",
                    precio = "$354.99"
                ),
            )
        }
}